/*:
 ## Egzersiz: Bir Alışveriş Listesi Oluşturmak

 Aşağıdaki sabitler, bir alışveriş listesine eklemek isteyebileceğiniz birkaç şeyi temsil ediyor:
*/
let yumurta = "Yumurta"
let sut = "Süt"
let peynir = "Peynir"
let ekmek = "Ekmek"
let pirinc = "Pirinç"
let yeniSatir = "\n"
//: - callout(Egzersiz): İlk değeri `""` olan bir liste değişkeni oluşturun. Yukarıdaki her sabiti, listeye birer birer ekleyin. Her parçanın arasında bir `yeniSatir` ekleyin. Hatırlayın, iki karakter dizisini `+` işareti ile birleştirebilirsiniz. 😉
//:
// Kodlama Alanı
var liste = ""

liste += yumurta + yeniSatir


//:
//: Bir sonraki egzersize geçin.
//:
//: [Geri](@previous)  |  Sayfa 18 / 20  |  [İleri: Koşul İfadeleri](@next)
