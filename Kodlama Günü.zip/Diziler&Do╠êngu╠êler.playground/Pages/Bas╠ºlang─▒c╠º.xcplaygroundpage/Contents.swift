//: # Mükemmel İkili: Diziler ve Döngüler
//: ---
//: Bu etkinliğimizde, programlamanın temellerini öğrenmek için Playground ortamını kullanacağız.\
//: Kısa bir turla başlayıp, sonrasında da biraz kod yazacağız. 🤓
//: * Listeler
//: * Dizi İfadeleri
//: * Dizinler
//: * Öğelerin Sayısı
//: * Dizileri İşlemek
//: * Döngüler
//: * Değişken Diziler
//: * Öğeler Eklemek
//: * Öğeler Çıkarmak
//: * Öğeleri Değiştirmek
//:
//:  Daha fazlasını öğrenmek için bir sonraki sayfaya geçelim! 🙂
//:
//:Sayfa 1 / 15  |  [İleri: Listeler](@next)
