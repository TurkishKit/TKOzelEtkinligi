//: ## Öğle Arası! 🥪
//: ### Öğrendiğiniz bütün bu yeni şeylerden sonra, biraz acıkmış olmalısınız. Merak etmeyin, bu ara boyunca sizleri lezzetli atıştırmalıklar ve diğer müthiş sürprizler bekliyor olacak! 😉
//: ### Uzmanından öneri: sadece yemekle kalmayın; gezinin, eğlenin, hatta dans edin! 💃
//: ---
/*:
 ## Etkinlik Akışı
 ### 11.50 - 13.00 | Öğle Arası
 ### 13.00 - 13.50 | **Swift ile Instagram** - Rana Taki
 ### 13.50 - 14.00 | Kahve Arası
 ### 14.00 - 14.50 | **Swift ile Instagram** - Rana Taki
 ### 14.50 - 15.00 | Kahve Arası
 ### 15.00 - 15.50 | **Swift ile Instagram** - Rana Taki
 ### 15.50 - 16.00 | **Kapanış**
 */
//: [Geri](@previous)  |  Tebrikler, bu Playground kitabının sonuna ulaştınız! 🎉🤓
