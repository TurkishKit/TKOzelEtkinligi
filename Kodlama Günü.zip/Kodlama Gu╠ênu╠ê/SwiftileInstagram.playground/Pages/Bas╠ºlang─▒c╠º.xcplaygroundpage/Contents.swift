//: ![Header View](instagram-cover.pdf)
//:
//: Bu oturumda interaktif Playground ortamında bir Instagram gönderisini oluşturan parçaları ve onları oluşturmak için kullanılan temel arayüz elemanlarını kodlayacaksınız. Kendi Instagram gönderinizi oluşturmak hiç bu kadar kolay ve eğlenceli olmamıştı!
//:
//: 
//: İşte Bu Oturumda Sizi Bekleyenler:
//: * Parçalara Ayırmak
//: * HeaderView
//: * BodyView
//: * FooterView
//: * Parçaları Birleştirmek
//:
//:\
//: İlk olarak bir Instagram gönderisini oluşturan parçaları keşfedelim.\
//: Sayfa 1 / 9  |  [İleri: Parçalara Ayırmak](@next)
