/*:
  ![Footer](instagram-parts-footer.pdf "Footer")
  Footer, bir gönderinin en altında yer alan parçadır. Gönderinizle beraber paylaştığınız yorumunuz, beğeni ve yorum sayısı bu alanda gösterilir.
  ### Footer'da Yer Alan Bilgiler:
  * Beğeni Sayısı
  * Gönderi İçeriği
  * Yorum Sayısı

 \
 Sonraki sayfada _Footer_ parçasını oluşturan arayüz elemanlarını nasıl kodlayacağımızı keşfedelim.\
 [Geri](@previous) | Sayfa 7 / 9 | [Footer Oluşturmak](@next)
 */
