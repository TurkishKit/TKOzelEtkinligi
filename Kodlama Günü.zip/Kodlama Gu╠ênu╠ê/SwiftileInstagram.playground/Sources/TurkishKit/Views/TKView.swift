import UIKit

public class TKView: UIView, ViewInitializable { }

