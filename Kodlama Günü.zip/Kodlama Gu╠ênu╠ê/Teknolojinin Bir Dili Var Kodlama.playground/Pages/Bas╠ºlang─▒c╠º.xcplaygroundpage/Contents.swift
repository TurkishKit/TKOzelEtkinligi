//: # Playground Temelleri
//: Bu eğitimde, programlamanın temellerini öğrenmek için Playground ortamını kullanacağız.\
//: Kısa bir turla başlayıp, sonrasında da biraz kod yazacağız. 🤓
//: * Playground Nedir?
//: * Hesaplamalar
//: * Yorum Satırları
//: * Hatalar
//: * Adlandırma ve Tanımlayıcılar
//: * Evcil Hayvan Problemi
//: * Bir Şeyleri Adlandırmak
//: * İsimler ve Otomatik Tamamlama
//: * İyi İsimler Seçmek
//: * Geliştiricilerin Dili

//: Aşağıdaki Playground simgesini görüyor musunuz?
//: Eğer görmüyorsanız, yukarıdaki menü çubuğundan **Editor > Show Rendered Markup** seçeneğine tıklamanız yeterli.
//:
//: ![Playground Logo](playground-logo.pdf)
//:
//: Eğer simgeyi görebiliyorsanız, başlamaya hazırız!
//:
//:Sayfa 1 / 7  |  [İleri: Playground Nedir?](@next)
