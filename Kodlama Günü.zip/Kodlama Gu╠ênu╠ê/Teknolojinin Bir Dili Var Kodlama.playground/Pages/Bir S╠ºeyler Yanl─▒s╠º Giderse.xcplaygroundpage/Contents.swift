//:  ## Bir Şeyler Yanlış Giderse 😰
//: Geliştiriciler hata yapar.\
//: (Hem de tahmin ettiğinizden daha sık.)
//:
//: Siz de kod yazdıkça ve uygulamalar geliştirdikçe hatalar yapacaksınız.
//:
//: _Paniğe kapılmayın._
//:
//: Kod yazarken bazen bir şeyler yanlış gidebilir; bu normaldir ve oldukça doğaldır.\
//: Hatasız kod olmaz. 🙂
//:
//: Kod yazmanın bir parçası da hatalar ile karşılaştığınızda onları çözmektir.
//:
//: İlk adım, aşırı heyecanlanmamaktır. Derin bir nefes alın.
//:
//: _Paniğe kapılmayın._
//:
//: Bir hata ile karşılaşmanız, yapamadığınız veya kötü bir geliştirici olduğunuz anlamına gelmez.\
//: Sadece, kodunuzda düzeltmeniz gereken bir hata olduğu anlamına gelir.
//:
//: Ve bu, kod geliştirme sürecinin bir parçasıdır.
//:
//:
//: \
//: Bir sonraki sayfada Playground ortamının, hataları bulmanızda nasıl yardımcı olabileceğini keşfedelim.
//:
//:[Geri: Yorum Satırları](@previous)  |  Sayfa 5 / 7  |  [İleri: Hatalar](@next)
