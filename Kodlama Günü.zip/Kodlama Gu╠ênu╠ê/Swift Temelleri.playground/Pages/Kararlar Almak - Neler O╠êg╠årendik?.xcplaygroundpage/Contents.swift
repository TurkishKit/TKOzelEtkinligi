/*:
 ## Neler Öğrendik?
 
 - Kararlar almak ve bu kararlar üzerinden hangi kodu çalıştıracağınızı seçmek, kodunuza yeni güçler kazandırır. 😉

 - Değeri `true` (doğru) veya `false` (yanlış) olabilen karşılarştırma operatörleri ile kararlar alınabilir.
 
 -  `if` ve `else` sayesinde, karşılaştırma ifadeleri ile kod parçaları çalıştırılabilir.
 
 ```
 let alıştırmaYapmakİstiyorum = true
 if alıştırmaYapmakİstiyorum {
    O zaman egzersizlere ilerleyelim! 😊
 }
 ```
 
 [Geri: Kalan Operatörü](@previous)  |  Sayfa 23  |  [İleri: Egzersiz - Koşul İfadeleri](@next)
*/
