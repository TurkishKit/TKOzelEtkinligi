/*:
 ## Egzersiz: Koşul İfadeleri
 
 Aşağıdaki açıklamaları kod şeklinde yeniden yazarak eğer ifadelerini daha iyi anlayabilirsiniz! 🤓
*/
let a = 20
let b = 30
let c = 20

// Eğer a değeri c değerine eşit ise, "a ve c aynı" yazın


// Eğer a değeri b değerinden küçükse, "b, a'dan önde" yazın


// Eğer b değeri a değerinden büyükse, "a, b'ye kaybediyor" yazın


// Eğer a değeri c değerine eşit veya daha az ise, "a, c'ye kaybediyor veya berabere" yazın


//: - callout(Egzersiz): Yukarıdaki her açıklamadan sonra, yönergeleri takip edecek kodlar ekleyin. (Büyüktür ve küçüktür işaretleri için, aç ağız kuralını hatırlayın. 😉)
//:
//: [Geri: Neler Öğrendik?](@previous)  |  Sayfa 24  |  [İleri: Egzersiz - Else (Değilse) Alıştırmaları](@next)
