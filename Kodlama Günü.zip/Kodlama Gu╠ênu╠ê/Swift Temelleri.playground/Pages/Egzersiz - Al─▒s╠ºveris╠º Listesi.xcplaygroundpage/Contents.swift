/*:
 ## Egzersiz: Bir Alışveriş Listesi Yapmak

 Aşağıdaki sabitler, bir alışveriş listesine eklemek isteyebileceğiniz birkaç şeyi temsil ediyor:
*/
let yumurta = "Yumurta"
let sut = "Süt"
let peynir = "Peynir"
let ekmek = "Ekmek"
let pirinc = "Pirinç"
let yeniSatir = "\n"
//: - callout(Egzersiz): İlk değeri `""` olan bir liste değişkeni oluşturun. Yukarıdaki her sabiti, listeye birer birer ekleyin. Her parçanın arasında bir `yeniSatir` ekleyin. Hatırlayın, iki karakter dizisini `+` işareti ile birleştirebilirsiniz. 😉






//: [Geri: Neler Öğrendik?](@previous)  |  Sayfa 14  |  [İleri: Kararlar Almak](@next)
