//: ## Egzersiz: Bir Konser Düzenlemek
//: Arkadaşınız, evcil hayvan gösterisini tamamladı. Sizin yardımlarınız sayesinde, gösteri büyük bir başarıyla gerçekleşti! 🐶🐱🎉
//:
//:Şimdi ise, arkadaşınız bir konser düzenleyecek. Biletler 10 TL'den satılıyor. Konser alanının kiralama ücreti 1000 TL. Posterleri yapmak ise 40 TL'ye mal oluyor. Konserin para kazandırıp kazandırmayacağı konusunda arkadaşınıza yardımcı olun.
// Biletlerin Sayısı
150

// Bilet Fiyatı
10

// Alan Kirası
1000

// Poster Maliyeti
40

// Biletlerin Toplam Değeri
150 * 10

// Toplam Harcama
1000 + 40

// Konserin Toplam Getirisi
(150 * 10) - (1000 + 40)
//: - callout(Egzersiz 🏃‍♀️): Yukarıdaki kodu örnek alarak, arkadaşınızın problemini daha iyi bir şekilde çözecek sabitler tanımlamak için let ifadeleri kullanın.
//:
//: Kodlarınızı aşağıya ekleyin. Başlayabilmenize yardımcı olmak için, sizin yerinize `biletlerinSayisi` değerini tanımladık.
let biletlerinSayisi = 150





//:
//:[Geri](@previous)  |  Sayfa 16 / 16  |  Tebrikler, bu Playground kitabının sonuna ulaştınız! 🎉🤓
//:
//:
/*:
_Telif hakkı © 2019 TurkishKit._\
_Orijinal içerik, Apple, Inc. tarafından sağlanan aşağıdaki lisans ile kullanılmıştır._

_Hiçbir ücret talep edilmeden burada işbu yazılımın bir kopyasını ve belgelendirme dosyalarını (“Yazılım”) elde eden herkese verilen izin; kullanma, kopyalama, değiştirme, birleştirme, yayımlama, dağıtma, alt lisanslama, ve/veya yazılımın kopyalarını satma eylemleri de dahil olmak üzere ve bununla kısıtlama olmaksızın, yazılımın sınırlama olmadan ticaretini yapmak için verilmiş olup, bunları yapmaları için yazılımın sağlandığı kişilere aşağıdakileri yapmak koşuluyla sunulur:_

_Yukarıdaki telif hakkı bildirimi ve işbu izin bildirimi yazılımın tüm kopyalarına veya önemli parçalarına eklenmelidir._

_YAZILIM “HİÇBİR DEĞİŞİKLİK YAPILMADAN” ESASINA BAĞLI OLARAK, TİCARETE ELVERİŞLİLİK, ÖZEL BİR AMACA UYGUNLUK VE İHLAL OLMAMASI DA DAHİL VE BUNUNLA KISITLI OLMAKSIZIN AÇIKÇA VEYA ÜSTÜ KAPALI OLARAK HİÇBİR TEMİNAT OLMAKSIZIN SUNULMUŞTUR. HİÇBİR KOŞULDA YAZARLAR VEYA TELİF HAKKI SAHİPLERİ HERHANGİ BİR İDDİAYA, HASARA VEYA DİĞER YÜKÜMLÜLÜKLERE KARŞI, YAZILIMLA VEYA KULLANIMLA VEYA YAZILIMIN BAŞKA BAĞLANTILARIYLA İLGİLİ, BUNLARDAN KAYNAKLANAN VE BUNLARIN SONUCU BİR SÖZLEŞME DAVASI, HAKSIZ FİİL VEYA DİĞER EYLEMLERDEN SORUMLU DEĞİLDİR._
*/
