//: ## Evcil Hayvan Problemi Özet
//: Bütün güncellemeleri yaptıktan sonra, kodlarınız şöyle görünüyor olmalı:
// Köpeklerin Sayısı
6

// Kedi Sayısı
5

// Kaplumbağa Sayısı
2

// Hamster Sayısı
1

// Toplam Hayvan Sayısı
6 + 5 + 2 + 1

// Toplam Memeli Sayısı
6 + 5 + 1
//: Playground sayfalarını bu şekilde kullanmak, arkadaşınızın sorununu çözdü. Her türden kaç adet hayvan olduğunu, tüm hayvanların sayısını ve tüm memelilerin sayısını takip edebildiniz.
//:
//: Ancak, bu deney esnasınnda hata yapmanın son derece kolay olduğunu fark etmiş olabilirsiniz. Her sayıyı birkaç yerde değiştirmeniz gerekti. Eğer sayıları her yerde güncellemeyi unutsaydınız, toplamlarınız yanlış olabilirdi.
//:
//: Ayrıca hangi sayı ile hangi hayvan türünü takip ettiğinizi unutmamanız gerekti. Her sayıyı birbirinden ayıran açıklamalar olmadan, her şeyi bir arada kontrol etmek oldukça zor olacaktır.
//:
//: Kod yazarken en çok işinize yarayacak şeylerden biri, bir şeylere isim verebilmenizdir. Aynı şeyi ifade eden sayıları tekrar yazmak yerine, onlara bir isim verebilirsiniz. Böylece ihtiyacınız olduğunda, kodunuzda herhangi bir yerde o sayılar yerine verdiğiniz isimleri kullanabilirsiniz! 😉
//:
//:\
//: Şimdi, bunu nasıl yapacağımızı öğrenelim!\
//:[Geri](@previous)  |  Sayfa 9 / 16  |  [İleri: Bir Şeyleri Adlandırmak](@next)
