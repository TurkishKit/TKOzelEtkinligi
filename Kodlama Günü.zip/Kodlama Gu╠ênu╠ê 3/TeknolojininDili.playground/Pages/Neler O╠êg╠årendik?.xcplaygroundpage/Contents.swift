//: ## Neler Öğrendik?
//: Bu oturumda, Playground ortamının ve sonuç alanının küçük bir turunu yaptık. Aynı zamanda kodlamaya adım atmanızı sağlayacak birkaç şey de öğrendiniz:
//: - callout(Öğrendikleriniz 🤓):
//:     - Matematiksel hesaplamalar yapmak
//:     - Yorum satırlarını kullanmak
//:     - Bir şeyler yanlış gittiğinde hataları bulmak ve düzeltmek
//:     - Geliştiricilerin problemleri nasıl çözdüğü
//:     - Değerlere isim vermenin problemleri çözmeyi nasıl kolaylaştırabileceği
//:     - Bir şeyleri Swift ile tanımlayabilmek
//:     - Anlaşılabilir bir kod için iyi isimler seçmek
//:     - _let_ kullanarak bir sabit tanımlamak ve ona değer atamak
//:
//:
/*:
 [Geri: Hatalar](@previous)  |  Sayfa 15 / 16  |  [İleri: Egzersiz - Bir Konser Düzenlemek](@next)
 */
