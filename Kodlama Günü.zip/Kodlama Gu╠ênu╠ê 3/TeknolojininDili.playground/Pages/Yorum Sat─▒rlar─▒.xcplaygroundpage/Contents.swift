//: ## Yorum Satırları
//: Geliştiriciler, kodlarının arasında açıklayıcı küçük notlar bırakırlar. Biz bu notlara _yorum satırı(comment line)_ deriz.
//: Bu notlar sayesinde projemize yeni dahil olan geliştiricilerin, kodumuzu anlamalarına yardımcı oluruz.
//:
//: Yorum satırları, Playground tarafından göz ardı edilir ve kodunuzun çalışmasını etkilemez.
//: 
//: Bir yorum satırı, çift eğik çizgi "//" ile başlar:
// Bu bir yorum satırıdır, kodununuzun çalışmasını etkilemez.
34 + 56 + 230

// Yorum satırları için sonuç alanında bir sonuç gösterilmez.
// 200 + 34 + 45
//: - Callout(Deney 🧪):
//:     - Dokuzuncu satırda bulunan `34 + 56 + 230` işleminin başına çift eğik çizgi işareti ekleyerek bu satırı bir _yorum satırına_ çevirmeyi deneyin.
//:     - `200 + 34 + 45` işleminin başındaki çift eğik çizgiyi silerek bu satırı bir kod satırına çevirin.
//:     - Mevcut işlemlerin bazılarını düzenlemeyi ve birkaç tane de kendiniz eklemeyi deneyin.
//:
//: Her değişiklik yaptığınızda sonuç alanının güncellendiğini görebilirsiniz.
//:
//:
//: \
//: Derin bir nefes alın ve bir sonraki sayfaya geçin 🙂
//:
//:[Geri ](@previous)  |  Sayfa 4 / 16  |  [İleri: Bir Şeyler Yanlış Giderse 😰](@next)
