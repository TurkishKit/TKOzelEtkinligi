//: ## Parçalara Ayırmak
//: Geliştiricilerin iyi oldukları konulardan biri de büyük ve karmaşık yapıları küçük ve anlaşılması kolay parçalara ayırarak sadeleştirmektir.
//: Bir Instagram gönderisini tasarlamak ve kodlamak, başta karmaşık gibi görünebilir. Fakat gönderiyi oluşturan parçaları düşünerek ve onları sırayla geliştirerek karmaşayı eğlenceye çevirmek sizin elinizde!
//:
//: ![Header View](instagram-parts.pdf)
//:
//:\
//: Bir sonraki sayfada Instagram gönderisinin ilk parçası olan _HeaderView_'ı tanıyalım.\
//:[Geri](@previous)  |  Sayfa 2 / 9  |  [İleri: Header Nedir?](@next)
