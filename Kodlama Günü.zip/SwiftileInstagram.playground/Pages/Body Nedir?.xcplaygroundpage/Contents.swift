/*:
  ![Body](instagram-parts-body.pdf "Body")
  
_Body_, bir Instagram gönderisinin en çarpıcı parçasıdır. Bu alanın büyük bir kısmını paylaşılan fotoğraflar oluşturur. Kullanıcılar kaydırmalı bir arayüz elemanı sayesinde fotoğraflar arasında gezinebilir. Kullanıcılar ayrıca gönderiyi beğenebilir, yorumlayabilir, arkadaşlarıyla paylaşabilir ve hatta kaydedebilirler.
 
  ### Body Parçasında Yer Alan Bilgiler:
  * Fotoğraflar
  * Beğeni Butonu
  * Yorum Butonu
  * Mesaj Butonu
* Sayfa Kontrolü
 * Kaydet Butonu
 
 \
 Şimdi ise _Body_ parçasını oluşturan arayüz elemanlarını nasıl kodlayacağımızı öğrenelim.\
 [Geri](@previous) | Sayfa 5 / 9 | [Body Oluşturmak](@next)
 */
