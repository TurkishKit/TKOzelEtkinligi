import UIKit
import PlaygroundSupport
/*:
 ## Body View Oluşturmak
 Body View'unuzun içine tanımlayacağınız elemanlar için bir tane View oluşturunuz.
 */
var bodyView = TKView(position: (0,0), size: (375,430))

/*:
## Fotoğraflar 📸
 ![Fotoğraflar](FotograflarMark.png "fotograflar")
Bir instagram gönderisinin en önemli kısmı, o gönderinin fotoğraflarıdır. Birkaç tane fotoğraf bir arada da konulabilir ve fotoğraflar arasında geçiş yapılabilir.

**Yapılması Gerekenler:**
1. Fotoğraflarınızı içinde bulunduracak bir tane *ScrollView* eklemek
2. Fotoğraflarınızın fotoğraf olduğunu belirtmek için hepsini birer *UIImage* olarak tanımlamak
2. Fotoğraflarınızı bir *ImageView*'a yerleştirmek
3. Fotoğraflarınızı yana kaydırabilmek için *ScrollView*'un içine yerleştirmek

* Callout(Tip💡):
Fotoğrafları tanımlarken birden fazla resim olduğundan array kullanınız.
*/

var imagesScrollView = TKScrollView()
imagesScrollView = TKScrollView(size: (375, 375))

let fotograf1 = UIImage.postFotografi1
let fotograf2 = UIImage.postFotografi2
let fotograf3 = UIImage.postFotografi3
let postImages = [fotograf1, fotograf2, fotograf3]

for photo in postImages {
    let postImageView = TKImageView(size: (375, 375), image: photo)
    
    imagesScrollView.addSubview(postImageView)
}

bodyView.addSubview(imagesScrollView)

/*:
 ## Sayfa Kontrolü 🚥
  ![Sayfa Kontrolü](PageControlMark.png "sayfaKontrolu")
Instagrama birden fazla fotoğraf konunca, fotoğrafların altında üç tane nokta belirir. Bu noktlardan biri mavi olmak üzere size kaç tane post olduğunu ve hangi postu görüntülediğinizi belirtir.
 
 * Callout(TKPageControl):
 TKPageControl, sayfa kontrolünü sağlar. Fotoğrafların kaydırıldığında noktaların renginin değişmesini sağlar.
 
 **Yapılması Gerekenler:**
 1. *TKPageControl* tanımlamak ve pozisyonunu ve boyunu ayarlamak
 2. Post sayısına göre nokta sayısını belirlemek
 3. Aktif olan ve olmayan noktaların renklerini belirlemek
 
*/
var sayfaKontrolu = TKPageControl(position: (375 / 2, imagesScrollView.bottom + 25))
sayfaKontrolu.numberOfDots = postImages.count
sayfaKontrolu.activeDotColor = .instaMavi
sayfaKontrolu.inactiveDotColor = .instaAcikGri

bodyView.addSubview(sayfaKontrolu)

/*:
 ## Beğeni Butonu ♥️
  ![Beğeni Butonu](LikeMark.png "begeniButonu")
 Beğeni butonu fotoğrafların altında bulunmaktadır bir fotoğrafı beğenip beğenmediğinizi belirlemektedir. Butona basıldığında kalbin içi renk değiştirir ve beğendiğinizi belli eder.
 
 **Yapılması Gerekenler:**
 1. Beğeni butonunu içinde tutmak için bir *TKButton* tanımlamak ve pozisyonunu ayarlamak
 2. Beğeni butonunu tanımladığınız *TKButton*'ın içine yerleştirmek
 3. Beğeni butonuna dokunulduğunda içini doldurmak
*/
let begeniButonu = TKButton(position: (12,imagesScrollView.bottom + 15), size: (26,26))

begeniButonu.normalImage = UIImage.bosBegeniIkonu
begeniButonu.selectedImage = UIImage.doluBegeniIkonu
begeniButonu.isAnimated = true

bodyView.addSubview(begeniButonu)

/*:
 ## Yorum Butonu 💬
  ![Yorum Butonu](CommentMark.png "yorumButonu")
 Yorum butonu gönderiye yorumlarınızı atmak için kullanılır. Bu yorumlar takip eden tüm kullanıcılar tarafından görülür.
 
 **Yapılması Gerekenler:**
 1. Yorum butonu simgesini içinde bulunduracak bir *TKButton* oluşturmak ve boyutunu ve pozisyonunu ayarlamak
 2. Oluşturduğunuz *TKButton*'ın içine yorum butonunun simgesini yerleştirmek
*/
let yorumButonu = TKButton(position: (begeniButonu.right + 10, imagesScrollView.bottom + 15), size: (26,26))
yorumButonu.normalImage = UIImage.yorumIkonu

bodyView.addSubview(yorumButonu)

/*:
 ## Gönder Butonu ✉️
  ![Gönder Butonu](SendMark.png "gonderButonu")
 Gönder butonu takipçilerinize bu postu göndermek için vardır. Gönderdiğiniz post diğer kullanıcıların mesajlarına gitmektedir.
 
 **Yapılması Gerekenler:**
 1. Gönder butonunuzu içinde tutmak için bir *TKButton* tanımlamak ve pozisyonunu ve boyutlarını ayarlamak
 2. Tanımladığınız *TKButton*'ın içinde gönder butonunun simgesini yerleştirmek
*/

let gonderButonu = TKButton(position: (yorumButonu.right + 10, imagesScrollView.bottom + 15), size: (26,26))
gonderButonu.normalImage = UIImage.mesajIkonu

bodyView.addSubview(gonderButonu)

/*:
 ## Kaydet Butonu📂,
  ![Kaydet Butonu](BookmarkMark.png "kaydetButonu")
 Kaydet butonu gönderiyi instagramdaki kaydedilenler kısmına kaydetmek için vardır. Sizin için önemli olan postları veya dönüp tekrar bakmak isteyeceklerinizi bu butona basarak kaydedebilirsiniz.
 
 **Yapılması Gerekenler:**
 1. Kaydet butonunu yerleştireceğiniz bir *TKButton* tanımlamak ve pozisyonunu ve boyutlarını ayarlamak
 2. Kaydet butonunu yarattığınız *TKButton*'ın içine tanımlamak
 3. Kaydet butonunun üstüne basıldığında içinin dolmasını sağlamak
*/
let kaydetButonu = TKButton(position: (sayfaKontrolu.right + 150,imagesScrollView.bottom + 15), size: (26,26))
kaydetButonu.normalImage = UIImage.bosKaydetIkonu
kaydetButonu.selectedImage = UIImage.doluKaydetIkonu
kaydetButonu.isAnimated = true

bodyView.addSubview(kaydetButonu)

PlaygroundPage.current.liveView = bodyView

/*:
 [BodyView İçindekiler](@previous) | Sayfa 5 | [FooterView İçindekiler](@next)
 */
