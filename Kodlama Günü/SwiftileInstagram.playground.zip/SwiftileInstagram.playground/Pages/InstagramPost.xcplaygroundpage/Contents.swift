import UIKit
import PlaygroundSupport

/*:
 ## Kendiniz Deneyin!
 Oluşturduğunuz instagram sayfasının değişkenlerini değiştirin!
 */

/*
 Hello,
 
 Bu sayfada tekrar bakılması gerekenler:
 
 - Açıklamaları nasıl yapacağımız
 - Sayfa Kontrolü aktif noktayı sayfa değiştikçe değiştirmek
 - Birkaç tane daha fotoğraf ekleyelim profil fotoğrafi ve diğerleri için
 - Türkçeleştirme nasıl oldu yorumlarınızı beklerim :)
 
 Rana 😊
 */

/*:
 ### Önceden oluşturduğunuz Instagram Sayfası aşağıda verilmiştir 😁
 Bu aşamada, aşağıdaki değişkenlerle oynayıp instagram sayfanızdaki değişiklikleri gözlemleyebilirsiniz!
 * Callout(Unutmayın!):
 Kodlamanın bir kısmı deneyip yanılmadan geçer!
 */
var instagramView = TKView(position: (0,0), size: (375,560))

var headerView = TKView(position: (0,0), size: (375,58))

var bodyView = TKView(position: (0, headerView.bottom), size: (375, 430))
/*:
 ## Header View
 */

var footerView = TKView(position: (0, bodyView.bottom), size: (375, 50))

let profilFotografiView = TKImageView(position: (10, 12), size: (32, 32), image: UIImage.profilFotografi)
profilFotografiView.isRounded = true
headerView.addSubview(profilFotografiView)

let kullaniciAdi = "turkishkit"
let kullaniciAdiLabel = TKLabel(position: (profilFotografiView.right + 10, 12))
kullaniciAdiLabel.text = kullaniciAdi
kullaniciAdiLabel.changeFont(size: 14, style: .semibold, color: .black)
headerView.addSubview(kullaniciAdiLabel)

let konumLabel = TKLabel(position: (profilFotografiView.right + 10, kullaniciAdiLabel.bottom))
konumLabel.text = "Workinton"
konumLabel.changeFont(size: 12, style: .regular, color: .black)
headerView.addSubview(konumLabel)

let seceneklerButonu = TKButton(position: (346, 18), size: (20, 20))
seceneklerButonu.normalImage = UIImage.seceneklerIkonu
headerView.addSubview(seceneklerButonu)

instagramView.addSubview(headerView)

/*:
 ## Body View
 */

let fotografKaydirmaView = TKScrollView(size: (375, 375))
let fotograf1 = UIImage.postFotografi1
let fotograf2 = UIImage.postFotografi2
let fotograf3 = UIImage.postFotografi3
let fotograflar = [fotograf1, fotograf2, fotograf3]
for fotograf in fotograflar
{
    let postImageView = TKImageView(size: (375, 375), image: fotograf)
    fotografKaydirmaView.addSubview(postImageView)
}
bodyView.addSubview(fotografKaydirmaView)

let sayfaKontrolu = TKPageControl(position: (375 / 2, fotografKaydirmaView.bottom + 25))
sayfaKontrolu.numberOfDots = fotograflar.count
sayfaKontrolu.activeDotColor = .instaMavi
sayfaKontrolu.inactiveDotColor = .instaAcikGri
bodyView.addSubview(sayfaKontrolu)

let begeniButonu = TKButton(position: (15, fotografKaydirmaView.bottom + 15), size: (24, 24))
begeniButonu.normalImage = .bosBegeniIkonu
begeniButonu.selectedImage = .doluBegeniIkonu
begeniButonu.isAnimated = true
bodyView.addSubview(begeniButonu)

let yorumButonu = TKButton(position: (begeniButonu.right + 12, fotografKaydirmaView.bottom + 15), size: (24, 24))
yorumButonu.normalImage = .yorumIkonu
bodyView.addSubview(yorumButonu)

let mesajButonu = TKButton(position: (yorumButonu.right + 12, fotografKaydirmaView.bottom + 15), size: (24, 24))
mesajButonu.normalImage = .mesajIkonu
bodyView.addSubview(mesajButonu)

let kaydetButonu = TKButton(position: (mesajButonu.right + 225, fotografKaydirmaView.bottom + 15), size: (24, 24))
kaydetButonu.normalImage = .bosKaydetIkonu
kaydetButonu.selectedImage = .doluKaydetIkonu
kaydetButonu.isAnimated = true
bodyView.addSubview(kaydetButonu)

instagramView.addSubview(bodyView)

/*:
 ## Footer View
 */

let begeniSayisi = 38
let begeniSayisiLabel = TKLabel(position: (15, 0))
begeniSayisiLabel.text = "\(begeniSayisi) likes"
begeniSayisiLabel.changeFont(size: 14, style: .semibold, color: .black)
footerView.addSubview(begeniSayisiLabel)

let gonderiYorumuView = TKLabel(position: (15, begeniSayisiLabel.bottom + 5), size: (375, 17))
let gonderiYorumuLabel = TKLabel(position: (0,0), size: (100,30))
gonderiYorumuLabel.text = "Burada, sizlerle olmak harika! "
gonderiYorumuLabel.changeFont(size: 14, style: .regular, color: .black)
gonderiYorumuView.addSubview(gonderiYorumuLabel)

let hashtagLabel = TKLabel(position: (gonderiYorumuLabel.right,0), size: (70,30))
hashtagLabel.text = "#tkozeletkinligi"
hashtagLabel.changeFont(size: 13, style: .semibold, color: .instaMavi)
gonderiYorumuView.addSubview(hashtagLabel)
footerView.addSubview(gonderiYorumuView)

let yorumSayisi = 21
let butunYorumlariGorButonu = TKButton(position: (15, gonderiYorumuView.bottom))
butunYorumlariGorButonu.title = "View all \(yorumSayisi) comments"
butunYorumlariGorButonu.changeFont(size: 14, style: .regular, color: .instaKoyuGri)
footerView.addSubview(butunYorumlariGorButonu)

instagramView.addSubview(footerView)


PlaygroundPage.current.liveView = instagramView

/*:
 [FooterView](@previous) | Sayfa 8 |
 */
