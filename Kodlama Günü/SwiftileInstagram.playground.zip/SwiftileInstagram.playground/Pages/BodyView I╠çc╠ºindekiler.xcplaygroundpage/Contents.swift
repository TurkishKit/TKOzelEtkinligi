/*:
 ## Body View
  ![BodyView](BodyViewPhoto.png "bodyView")
 Body View, instagram postumuzun en çarpıcı sayfasıdır. Büyük bir kısmı fotoğraflardan oluşmaktadır ve aynı zamanda butonları bulundurmaktadır.
 
 ### Body View'un içindekiler
 * Fotoğraflar
 * Beğeni Butonu
 * Yorum Butonu
 * Gönder Butonu
 * Kaydet Butonu
 * Sayfa Kontrolü
 
 [HeaderView](@previous) | Sayfa 4 | [BodyView](@next)
*/
