/*:
  ## Header View
  Header View, bir gönderi sayfasında en üstte bulunan ve profil fotoğrafı, kullanıcı adı gibi çeşitli bilgileri barındıran bir kısımdır.
  
  ![Header View](HeaderViewPhoto.png "headerView")
  
  ### Header View'un içindekiler:
  * Profil fotoğrafı
  * Kullanıcı adı
  * Lokasyon bilgisi
  * More butonu
 
 [Başlangıç](@previous) | Sayfa 2 | [HeaderView](@next)
 */


