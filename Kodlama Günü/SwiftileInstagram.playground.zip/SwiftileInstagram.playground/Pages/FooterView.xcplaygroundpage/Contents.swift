import UIKit
import PlaygroundSupport
/*:
  ## Footer View Oluşturmak
 Footer View'unuzun içine tanımlayacağınız elemanları tek bir yerde toplamak için bir tane View oluşturunuz.
 */
let footerView = TKView(position: (0,0), size: (375,90))
/*:
  ## Beğeni Sayısı ♥️
   ![Beğeni Sayısı](LikeCountMark.png "begeniSayisi")
  Bu sayı gönderinizin kaç kişi tarafından beğenildiğini gösterir.
  * Callout(Dikkat❗️):
  Beğeni sayısı, beğeni butonuna bastığınızda bir beğeni kadar artmalıdır.
  
  **Yapılması Gerekenler:**
  1. Beğeni sayısını belirlemek
  2. Beğeni sayısını içinde tutacak bir *Label* tanımlamak
  3. Tanımladığınız *Label*'ın yazısını değiştirmek
  4. *Label*'ın içindeki yazının fontunu bold yapmak ve boyutunu ayarlamak
  */
let begeniSayisi = 38
let begeniSayisiLabel = TKLabel(position: (10,10), size: (80,40))

 /*:
  Beğeni sayısını Label'ın içinde görmek için Label'ın yazısını değiştiriniz.
  */
 begeniSayisiLabel.text = "\(begeniSayisi) likes"
 /*:
  * Callout(Dikkat❗️):
  Beğeni sayısı Footer View'da çarpıcı bir kısımdır. Bu yüzden *beğeniSayısıLabel*'ını bold yapmanız gerekir.
  */
 begeniSayisiLabel.changeFont(size: 14.0, style: .semibold, color: .black)

footerView.addSubview(begeniSayisiLabel)

/*:
 ## Gönderi Yorumu 🏷
  ![Gönderi Yorumu](CaptionMark.png "gonderiYorumu")
 Gönderi yorumunuz, fotoğraflarınız altına yaptığınız küçük açıklamalardır. Bu açıklamaların arasında kendi düşünceniz ve hastag bulunur. Gönderi yorumu Instagram gönderinizi kişileştirmenizi sağlar.
 
 **Yapılması Gerekenler:**
 1. Gönderi yorumunuz için bir *Label* oluşturmak ve pozisyonunu ve boyutunu ayarlamak.
 2. Hashtaginiz için bir *Label* oluşturmak.
 2.  *HashtagLabel*'ınız için hashtaginizi belirlemek.
 3. *hashtagLabel*'ın fontunu, boyutunu ve rengini değiştirmek.
 4. Gönderi yorumunuzu oluşturduğunuz *Label*'ın içine yazmak ve *hashtagLabel*'ı eklemek.
 
 */
let gonderiYorumuView = TKLabel(position: (10, begeniSayisiLabel.bottom + 5), size: (375, 17))

/*:
* Callout(#hashtag):
 Hashtagleriniz kalın fontta olmalıdır!
 */
let gonderiYorumuLabel = TKLabel(position: (0,0), size: (100,30))
gonderiYorumuLabel.text = "Burada, sizlerle olmak harika! "
gonderiYorumuLabel.changeFont(size: 14, style: .regular, color: .black)
gonderiYorumuView.addSubview(gonderiYorumuLabel)
let hashtagLabel = TKLabel(position: (gonderiYorumuLabel.right,0), size: (70,30))
hashtagLabel.text = "#tkozeletkinligi"
hashtagLabel.changeFont(size: 13, style: .semibold, color: .instaMavi)
gonderiYorumuView.addSubview(hashtagLabel)


footerView.addSubview(gonderiYorumuView)
/*:
 ## Bütün Yorumları Gör 🔎
  ![Bütün Yorumları Gör](ViewAllCommentsMark.png "butunYorumlariGor")
 Bütün yorumları gör kısmında gönderinizin kaç tane yorum aldığını görebilirsiniz. Bu kısım çok çarpıcı olmamakla beraber daha açık renklidir. Başka bir kullanıcı yorum attığında bütün yorumları gör kısmındaki toplam yorum sayısı değişmektedir.
 
 **Yapılması Gerekenler:**
 1. Bütün yorumları gör yazısını içinde bulunduran bir *TKLabel* oluşturmak.
 2. Bütün yorumları gör yazısının rengini ve fontunu değiştirmek.
 3. Yorum sayısını belirlemek.
 4. *TKLabel*'ın içindeki yazıyı belirlemek ve yorum sayısını eklemek.
 
 * Callout(Dikkat etmeniz gereken özellikler):
    * *Label*'ın açık gri renkte olması
    * Yorum sayısı için bir değişkeninizin olması
 */
let butunYorumlariGorLabel = TKLabel(position: (10,gonderiYorumuView.bottom + 5), size: (375,60))
let yorumSayisi = 21
butunYorumlariGorLabel.text = "View all \(yorumSayisi) comments"
butunYorumlariGorLabel.changeFont(size: 14, style: .medium, color: .instaAcikGri)
footerView.addSubview(butunYorumlariGorLabel)

/*:
 ## Footer View'u Birleştirmek
 Postunuzun en son kısmı olan Footer View'un elemanlarını kodlamayı bitirdiniz!
 
 Bütün elemanları *FooterView* oluşturarak birleştiriniz.
*/


PlaygroundPage.current.liveView = footerView

/*:
 [FooterView İçindekiler](@previous) | Sayfa 7 | [Instagram Post](@next)
 */
