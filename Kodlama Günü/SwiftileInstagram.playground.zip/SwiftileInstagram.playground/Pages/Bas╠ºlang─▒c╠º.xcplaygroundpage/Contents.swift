/*:
 # Swift ile Instagram Oturumuna Hoşgeldiniz!
 ### Bu oturumda Apple'ın interaktif Playground platformlarını kullanarak Swift ile bir Instagram gönderisi tasarlayıp kodlayabileceksiniz.

 ## Öğrenecekleriniz:
 * **HeaderView**
 * **BodyView**
 * **FooterView**
 * **Instagram Postunu Görüntüleme**
 
 | Sayfa 1 | [HeaderView İçindekiler](@next)
 */


