/*:
## Footer View 📱
 ![Footer View](FooterViewPhoto.png "footerView")
Footer view, bir gönderinin en altındaki kısımdır. Bu kısımda fotoğraflarınıza gelen beğeni sayısını ve yorumları görebilirsiniz.
 
### Footer View'un içindekiler
* Beğeni Sayısı
* Gönderi Yorumu
* Bütün Yorumları Gör
 
 [BodyView](@previous) | Sayfa 6 | [FooterView](@next)
*/
