import UIKit
import PlaygroundSupport
/*:
 ## Header View Oluşturmak
 Header View'a ekleyeceğiniz elemanları bir tane View'un içine tanımlayınız.
 */
var headerView = TKView(position: (0,0), size: (375, 58))
/*:
 ## Profil Fotoğrafı 👩‍💻👨‍💻
  ![Profil Fotoğrafı](ProfilePhotoMark.png "profilFotografi")
 Profil fotoğrafı, hesabınıza girip giremeyen herkesin gördüğü, küçük, daire şeklinde bir fotoğraftır.
 
 **Yapılması gerekenler:**
 1. Header kısmını içinde bulunduracak bir *TKView* eklemek ve boyutunu belirlemek.
 2. Profil fotoğrafını bir bir fotoğraf olarak belirtmek için UIImage olarak tanımlamak ve fotoğraf adını yerleştirmek.
 3. Bir *Image View* tanımlayarak profil fotoğrafını içine yerleştirmek. Bu *Image View*'un sayfadaki pozisyonunu ve boyoutunu belirlemek.
 4. Profil fotoğrafının kenarlarını yuvarlak yapmak.
 5. Tanımladığınız *profilFotografiView*'u *view*'un içine yerleştirmek.
*/
let profilFotografi = UIImage.profilFotografi

let profilFotografiView = TKImageView(position: (10,12), size: (32,32), image: profilFotografi)

profilFotografiView.isRounded = true

headerView.addSubview(profilFotografiView)
/*:
 ## Kullanıcı Adı 👤
  ![Username](UsernameMark.png "username")
 Kullanıcı adı, instagrama atılan postların hangi kullanıcıya ait olduğunu belirler.
 
 * Callout(Dikkat❗️):
 Kullanıcı adının ön plana çıkması için semi bold (kalın) yazılması gerekir.
 
**Yapılması Gerekenler:**
 1. Kullanıcı adınızı tutacak bir *Label* tanımlamak ve pozisyonunu belirlemek.
 2.  Bir kullanıcı adı belirlemek.
 3. Kullanıcı adınızın fontunu değiştirmek.
 */
let kullaniciAdiLabel = TKLabel(position: (profilFotografiView.right + 7, 15), size: (200, 30))
kullaniciAdiLabel.text = "turkishkit"
kullaniciAdiLabel.changeFont(size: 14, style: .semibold, color: .black)

headerView.addSubview(kullaniciAdiLabel)

/*:
 ## Konum Bilgisi 🗺
  ![Location](LocationMark.png "location")
 Konum bilgisi postunuzun nerede olduğunu belirtir. Bu bilginin çok çarpıcı olmaması gerekir o yüzden kullanıcı adından daha küçüktür ve bold değildir.
 
 **Yapılması Gerekenler:**
 1. Konumunuz için bir *Label* oluşturmak ve pozisyonunu ayarlamak.
 2. Bir konum belirlemek.
 3. Yazının fontunu ve boyutunu ayarlamak.
 */
let konumLabel = TKLabel(position: (profilFotografiView.right + 7, kullaniciAdiLabel.bottom), size: (100,20))
konumLabel.text = "Workinton"
konumLabel.changeFont(size: 10, style: .regular, color: .black)

headerView.addSubview(konumLabel)
/*:
 ## Seçenekler Butonu
  ![Seçenekler](SeceneklerMark.png "secenekler")
 Seçenekler butonu, postun sağ üst köşesindeki üç nokta olmak üzere postu şikayet etmeye, linkini kopyalamaya veya başka bir uygulama kullanarak paylaşmaya yarar.
 
 **Yapılması Gerekenler:**
 1. Seçenekler butonu için bir *Button* oluşturmak ve pozisyonunu ve büyüklüğünü ayarlamak
 2. Oluşturduğunuz *Button*'un içine seçenekler butonunun fotoğrafını yerleştirmek
 */
let seceneklerButonu = TKButton(position: (346, 18), size: (20, 20))

seceneklerButonu.normalImage = UIImage.seceneklerIkonu

headerView.addSubview(seceneklerButonu)
/*:
 * Callout(Not🖋):
 *UIImage* kısmındaki *for* ifadesi, butonun içine yerleştirdiğiniz resmin ne zaman gözüktüğünü belirtmektedir. Mesela, *.normal* dediğinizde butonun normal, basılmamış halinde o resim gözükecek demektir.
 */

/*:
 ## Yaptıklarınızı Playground'un Live View Kısmında Görüntüleyin!📱
 
 Post sayfanızın ilk kısmını tamamladınız!😄🎉

 HeaderView'unuzu canlı görebilmek için Playground'un LiveView kısmına eklemeniz gerekecektir.
*/

PlaygroundPage.current.liveView = headerView

/*:
 [HeaderView İçindekiler](@previous) | Sayfa 3 | [BodyView İçindekiler](@next)
 */

