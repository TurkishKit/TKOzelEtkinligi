/*:
  ![Header](instagram-parts-header.pdf "Header")
  
Bir Instagram gönderisinin en üstünde bulunan alana _Header_ deriz. Bu alan, gönderiyi paylaşan hesap ve lokasyonu hakkında bilgiler içerir.
 
  ### Header'da Yer Alan Bilgiler:
  * Profil Fotoğrafı
  * Kullanıcı Adı
  * Lokasyon Bilgisi
  * Detay Butonu
 
 \
 Şimdi ise _Header_ parçasını oluşturan arayüz elemanlarını nasıl kodlayacağımızı öğrenelim.\
 [Geri](@previous) | Sayfa 3 / 9 | [Header Oluşturmak](@next)
 */
