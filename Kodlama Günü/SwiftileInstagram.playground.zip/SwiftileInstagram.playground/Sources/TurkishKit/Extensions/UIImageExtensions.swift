import UIKit

public extension UIImage {
    
    // MARK: Icon Library
    class var seceneklerIkonu: UIImage? {
        return UIImage(named: "more-icon-filled")
    }
    
    class var bosBegeniIkonu: UIImage? {
        return UIImage(named: "heart-icon-line")
    }
    
    class var doluBegeniIkonu: UIImage? {
        return UIImage(named: "heart-icon-filled")
    }
    
    class var yorumIkonu: UIImage? {
        return UIImage(named: "comment-icon-line")
    }
    
    class var mesajIkonu: UIImage? {
        return UIImage(named: "message-icon-line")
    }
    
    class var bosKaydetIkonu: UIImage? {
        return UIImage(named: "bookmark-icon-line")
    }
    
    class var doluKaydetIkonu: UIImage? {
        return UIImage(named: "bookmark-icon-filled")
    }
    
    // Image Library
    class var profilFotografi: UIImage {
        return UIImage(named: "profile-image")!
    }
    
    class var postFotografi1: UIImage {
        return UIImage(named: "post-image-1.jpg")!
    }
    
    class var postFotografi2: UIImage {
        return UIImage(named: "post-image-2.jpg")!
    }
    
    class var postFotografi3: UIImage {
        return UIImage(named: "post-image-3.jpg")!
    }
}
